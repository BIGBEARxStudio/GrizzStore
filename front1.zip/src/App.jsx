import { AnimatePresence, motion } from 'framer-motion'
import { BrowserRouter, Link, Route, Routes, useLocation } from 'react-router-dom'
import FloatingWA from './components/FloatingWA'
import AdminPanel from './pages/AdminPanel'
import Auth from './pages/Auth'
import Cart from './pages/Cart'
import Home from './pages/Home'
import Products from './pages/Products'
import Sublimation from './pages/Sublimation'

const page = {
  initial: { opacity: 0, y: 12 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.38 } },
  exit: { opacity: 0, y: -8, transition: { duration: 0.25 } }
}

function AnimatedRoutes() {
  const loc = useLocation()
  return (
    <AnimatePresence mode="wait">
      <Routes location={loc} key={loc.pathname}>
        <Route path="/" element={<motion.div variants={page} initial="initial" animate="animate" exit="exit"><Home /></motion.div>} />
        <Route path="/products" element={<motion.div variants={page} initial="initial" animate="animate" exit="exit"><Products /></motion.div>} />
        <Route path="/sublimation" element={<motion.div variants={page} initial="initial" animate="animate" exit="exit"><Sublimation /></motion.div>} />
        <Route path="/cart" element={<motion.div variants={page} initial="initial" animate="animate" exit="exit"><Cart /></motion.div>} />
        <Route path="/admin" element={<motion.div variants={page} initial="initial" animate="animate" exit="exit"><AdminPanel /></motion.div>} />
        <Route path="/auth" element={<motion.div variants={page} initial="initial" animate="animate" exit="exit"><Auth /></motion.div>} />
      </Routes>
    </AnimatePresence>
  )
}

export default function App() {
  return (

    <BrowserRouter>
      <header className="gb-header">
        <div className="gb-container">
          <div className="gb-left">
            <Link to="/" className="gb-logo">GRIZZLIES</Link>
          </div>
          <nav className="gb-nav">
            <Link to="/products">Merch</Link>
            <Link to="/sublimation">Sublimation</Link>
            <Link to="/cart" className="gb-cta">Cart</Link>
            <Link to="/auth">Sign In</Link>
            <Link to="/admin">Admin</Link>
          </nav>
        </div>
      </header>
      <main className="gb-main gb-container">
        <AnimatedRoutes />
      </main>
      <footer className="gb-footer">
        <div className="gb-container">© {new Date().getFullYear()} Grizzlies • Built by Bigbear</div>
      </footer>
      <FloatingWA />
    </BrowserRouter>

  )
}
