// FileUploader.jsx (updated)
import { useState } from 'react';
import { supabase } from '../api/supabaseClient';

export default function FileUploader({ onUpload }) {
  const [loading, setLoading] = useState(false);

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    try {
      // Save into a temp folder; public URL returned
      const filePath = `uploads/temp/${Date.now()}_${file.name}`;
      const { data, error } = await supabase.storage.from('designs').upload(filePath, file);
      if (error) throw error;
      const { data: urlData } = supabase.storage.from('designs').getPublicUrl(data.path);
      // Return the public URL to the parent; parent will include it in WA message.
      onUpload(urlData.publicUrl);
      // NOTE: the file remains in storage until you clean it up server-side (script provided).
    } catch (err) {
      alert(err.message || 'Upload failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <input type="file" accept="image/*,application/pdf" onChange={handleFile} />
      {loading && <div style={{ fontSize: 12, color: '#ccc' }}>Uploading…</div>}
      <div style={{ fontSize: 12, color: '#aaa', marginTop: 6 }}>Optional — ask customers to send larger assets via WhatsApp if needed.</div>
    </div>
  );
}
