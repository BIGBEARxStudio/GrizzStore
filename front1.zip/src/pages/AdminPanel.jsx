import { useEffect, useState } from 'react'
import { supabase } from '../api/supabaseClient'

export default function AdminPanel() {
  const [session, setSession] = useState(null)
  const [products, setProducts] = useState([])
  const [form, setForm] = useState({ id: null, name: '', description: '', price: '', category: 'merch', image_url: '', active: true })
  // inside AdminPanel: add state previewUrl
  const [previewUrl, setPreviewUrl] = useState(null);

  // in the upload handler before sending to storage:
  const f = e.target.files[0];
  if (f) {
    setPreviewUrl(URL.createObjectURL(f));
    // then upload and replace previewUrl with returned publicUrl if you want
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session))
    const { data: listener } = supabase.auth.onAuthStateChange((_e, sess) => setSession(sess))
    load()
    return () => listener.subscription.unsubscribe()
  }, [])

  async function load() { const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false }); setProducts(data || []) }

  async function save() {
    const payload = { name: form.name, description: form.description, price: Number(form.price || 0), image_url: form.image_url, category: form.category, active: form.active }
    if (form.id) await supabase.from('products').update(payload).eq('id', form.id)
    else await supabase.from('products').insert(payload)
    setForm({ id: null, name: '', description: '', price: '', category: 'merch', image_url: '', active: true }); load()
  }
  async function edit(p) { setForm({ ...p }); window.scrollTo({ top: 0, behavior: 'smooth' }) }
  async function del(id) { if (!confirm('Delete?')) return; await supabase.from('products').delete().eq('id', id); load() }
  async function signIn() { const email = prompt('Admin email'); const pw = prompt('password'); const { error } = await supabase.auth.signInWithPassword({ email, password: pw }); if (error) alert(error.message) }
  async function signOut() { await supabase.auth.signOut(); setSession(null) }

  async function upload(e) {
    const f = e.target.files[0]; if (!f) return
    const path = `products/${Date.now()}_${f.name}`
    const { data, error } = await supabase.storage.from('designs').upload(path, f)
    if (error) return alert(error.message)
    const { data: url } = supabase.storage.from('designs').getPublicUrl(data.path)
    setForm(fr => ({ ...fr, image_url: url.publicUrl }))
  }

  return (
    <div className="admin-grid">
      <div className="admin-card">
        {!session ? (
          <div>
            <p>Sign in as admin to manage products</p>
            <button className="button" onClick={signIn}>Sign in</button>
          </div>
        ) : (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>Signed in</div>
            <div><button className="button" onClick={signOut}>Sign out</button></div>
          </div>
        )}

        <div style={{ marginTop: 12 }}>
          <div className="label">Name</div>
          <input className="input" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} />
          <div className="label mt-2">Description</div>
          <textarea className="input" value={form.description} onChange={e => setForm({ ...form, description: e.target.value })} />
          <div className="label mt-2">Price</div>
          <input className="input" value={form.price} onChange={e => setForm({ ...form, price: e.target.value })} />
          <div className="label mt-2">Category</div>
          <select className="input" value={form.category} onChange={e => setForm({ ...form, category: e.target.value })}>
            <option value="merch">Merch</option>
            <option value="sublimation">Sublimation</option>
            <option value="sublimation-packet">Sublimation Packet</option>
          </select>
          <div style={{ marginTop: 8 }}>
            <input type="file" onChange={upload} />
            {form.image_url && <img src={form.image_url} style={{ maxWidth: 140, marginTop: 8 }} />}
          </div>
          <label style={{ display: 'block', marginTop: 8 }}><input type="checkbox" checked={form.active} onChange={e => setForm({ ...form, active: e.target.checked })} /> Active</label>
          <div style={{ marginTop: 10, display: 'flex', gap: 8 }}>
            <button className="button" onClick={save}>{form.id ? 'Save' : 'Create'}</button>
            <button className="button" onClick={() => setForm({ id: null, name: '', description: '', price: '', category: 'merch', image_url: '', active: true })} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.06)' }}>Reset</button>
          </div>
        </div>
      </div>

      <div className="admin-card">
        <h3>Products</h3>
        <div style={{ display: 'grid', gap: 10, marginTop: 10 }}>
          {products.map(p => (
            <div key={p.id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: 8, background: 'rgba(255,255,255,0.02)', borderRadius: 8 }}>
              <div>
                <div style={{ fontWeight: 700 }}>{p.name}</div>
                <div style={{ color: '#bdbdbd' }}>{p.category} • R{p.price}</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="button" onClick={() => edit(p)} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.06)' }}>Edit</button>
                <button className="button" onClick={() => del(p.id)} style={{ background: 'transparent', border: '1px solid rgba(255,255,255,0.06)', color: '#ff7a7a' }}>Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
