// Sublimation.jsx (replace existing)
import { useEffect, useState } from 'react';
import { supabase } from '../api/supabaseClient';
import useCart from '../hooks/useCart';
import '../styles/global.scss';

export default function Sublimation() {
  const [packets, setPackets] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [details, setDetails] = useState({ size: 'M', color: 'White', quantity: 1 });
  const { add } = useCart();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const { data } = await supabase.from('products').select('*').in('category', ['sublimation', 'sublimation-packet']).eq('active', true);
      setPackets(data || []);
      setLoading(false);
    }; load()
  }, []);

  const selectedPacket = packets.find(p => p.id === selectedId);

  function selectPacket(id) {
    // toggle: if clicking same selected, deselect
    setSelectedId(prev => prev === id ? null : id);
    // Optional: disable others visually (handled in render)
  }

  function onAdd() {
    if (!selectedPacket) return alert('Pick a sublimation package');
    const item = { ...selectedPacket, name: `${selectedPacket.name} (Sublimation)` };
    add(item, details.quantity, { details });
    alert('Added to cart');
  }

  return (
    <div>
      <h2 style={{ marginBottom: 12 }}>Sublimation Orders</h2>
      {loading ? <div>Loading...</div> : (
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 16 }}>
          <div>
            <div className="grid">
              {packets.map(p => {
                const isSelected = selectedId === p.id;
                const disabled = selectedId && !isSelected;
                return (
                  <div key={p.id}
                    className="product"
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 12,
                      opacity: disabled ? 0.45 : 1,
                      pointerEvents: disabled ? 'none' : 'auto',
                      border: isSelected ? '2px solid var(--accent)' : '1px solid rgba(255,255,255,0.03)'
                    }}>
                    <img src={p.image_url || 'https://placehold.co/200x150'} style={{ width: 120, height: 80, objectFit: 'cover', borderRadius: 8 }} />
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700 }}>{p.name}</div>
                      <div style={{ color: '#bdbdbd', fontSize: 13 }}>{p.description}</div>
                    </div>
                    <div style={{ textAlign: 'right' }}>
                      <div style={{ fontWeight: 700, color: 'var(--accent)' }}>R {p.price}</div>
                      <button className="button" onClick={() => selectPacket(p.id)} style={{ marginTop: 8, borderRadius: 12 }}>
                        {isSelected ? 'Selected' : 'Select'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          <aside className="order-card">
            <div className="title">Order Details</div>
            <div className="desc">Configure sizes, colours and quantities. Attach design files in cart or send on WhatsApp.</div>

            <div className="mt-2">
              <label className="label">Packet</label>
              <div style={{ marginBottom: 8 }}>
                {/* Styled select fallback: shows selected packet */}
                <select className="styled-select" value={selectedId || ''} onChange={e => selectPacket(e.target.value)}>
                  <option value="">-- pick a packet --</option>
                  {packets.map(p => <option key={p.id} value={p.id}>{p.name} — R{p.price}</option>)}
                </select>
              </div>

              <label className="label">Size</label>
              <input value={details.size} onChange={e => setDetails({ ...details, size: e.target.value })} className="input" />

              <label className="label mt-2">Color</label>
              <input value={details.color} onChange={e => setDetails({ ...details, color: e.target.value })} className="input" />

              <label className="label mt-2">Quantity</label>
              <input type="number" value={details.quantity} onChange={e => setDetails({ ...details, quantity: Number(e.target.value) })} className="input" />

              <div style={{ marginTop: 12 }}>
                <button className="button" onClick={onAdd} disabled={!selectedPacket}>Add to Cart</button>
              </div>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
