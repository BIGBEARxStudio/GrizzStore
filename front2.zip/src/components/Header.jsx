import React from 'react'
import { Link } from 'react-router-dom'
import CartButton from './CartButton'

export default function Header(){ 
  return (
    <header className="glass-header">
      <div className="glass-inner gb-container">
        <div className="left">
          <Link to="/" className="glass-logo">Grizzlies Clothing Store</Link>
        </div>
        <nav className="glass-nav">
          <Link to="/products">Merch</Link>
          <Link to="/sublimation">Sublimation</Link>
          <Link to="/orders">My Orders</Link>
        </nav>
        <div className="right">
          <CartButton />
        </div>
      </div>
    </header>
  )
}
