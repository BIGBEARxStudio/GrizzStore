import React, { useState } from 'react'
import { supabase } from '../api/supabaseClient'

export default function Auth(){
  const [email, setEmail] = useState('')
  const [pw, setPw] = useState('')

  async function signIn(){
    const { error } = await supabase.auth.signInWithPassword({ email, password: pw })
    if(error) alert(error.message)
    else alert('Signed in')
  }

  return (
    <div style={{maxWidth:420}}>
      <h3>Admin Sign In</h3>
      <div className="label">Email</div>
      <input className="input" value={email} onChange={e=> setEmail(e.target.value)} />
      <div className="label mt-2">Password</div>
      <input type="password" className="input" value={pw} onChange={e=> setPw(e.target.value)} />
      <div style={{marginTop:10}}>
        <button className="button" onClick={signIn}>Sign in</button>
      </div>
    </div>
  )
}
