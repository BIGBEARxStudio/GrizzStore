import { useEffect, useState } from 'react'
import { supabase } from '../api/supabaseClient'
import ProductCard from '../components/ProductCard'

export default function Products() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let mounted = true
    async function load() {
      const { data, error } = await supabase.from('products').select('*').eq('category', 'merch').eq('active', true)
      if (error) console.error(error)
      if (mounted) setItems(data || [])
      setLoading(false)
    }
    load()
    return () => mounted = false
  }, [])

  return (
    <div>
      <h2 style={{ marginBottom: 12 }}>Shop Merch</h2>

      {loading ? <div>Loading...</div> : (
        <div className="grid">
          {items.map(p => <ProductCard key={p.id} product={p} />)}
        </div>
      )}

    </div>
  )
}
