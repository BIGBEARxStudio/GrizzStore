import React, { useState } from 'react'
import { supabase } from '../api/supabaseClient'

export default function FileUploader({ onUpload }){
  const [loading, setLoading] = useState(false)
  async function handle(e){
    const file = e.target.files[0]
    if(!file) return
    setLoading(true)
    const path = `designs/${Date.now()}_${file.name}`
    const { data, error } = await supabase.storage.from('designs').upload(path, file)
    if(error){ alert(error.message); setLoading(false); return }
    const { data: url } = supabase.storage.from('designs').getPublicUrl(data.path)
    onUpload(url.publicUrl)
    setLoading(false)
  }
  return (
    <div>
      <input type="file" onChange={handle} />
      {loading && <div>Uploading...</div>}
    </div>
  )
}
