import React from 'react'
import { motion } from 'framer-motion'
import useCart from '../hooks/useCart'

export default function ProductCard({product}) {
  const { add } = useCart()
  return (
    <motion.div layout className="product" whileHover={{ y: -6 }} initial={{ opacity: 0, y: 8 }} animate={{ opacity:1, y:0 }}>
      <img src={product.image_url || 'https://placehold.co/400x300'} alt={product.name} />
      <div className="name">{product.name}</div>
      <div className="desc" style={{color:'#bdbdbd',fontSize:13}}>{product.description}</div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:8}}>
        <div className="price">R {product.price}</div>
        <button className="button" onClick={()=> add(product,1)}>Add</button>
      </div>
    </motion.div>
  )
}
