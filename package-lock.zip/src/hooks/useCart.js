import { useState, useEffect } from 'react'

export default function useCart(){
  const [items, setItems] = useState(() => {
    try { return JSON.parse(localStorage.getItem('bb_cart')||'[]') } catch(e){ return [] }
  })

  useEffect(()=>{ localStorage.setItem('bb_cart', JSON.stringify(items)) }, [items])

  const add = (product, qty=1, extras={}) => {
    setItems(prev=>{
      const idx = prev.findIndex(p=>p.id===product.id && JSON.stringify(p.extras)===JSON.stringify(extras))
      if(idx>-1){
        const copy = [...prev]; copy[idx].qty += qty; return copy
      }
      return [...prev, { ...product, qty, extras }]
    })
  }

  const remove = (id) => setItems(prev=>prev.filter(i=>i.id!==id))
  const clear = () => setItems([])
  const total = items.reduce((s,i)=> s + Number(i.price||0) * i.qty, 0)

  const attachFile = (url) => {
    setItems(prev=>{
      if(prev.length===0) return prev
      const copy = [...prev]
      const last = copy[copy.length-1]
      last.extras = last.extras || {}
      last.extras.files = last.extras.files || []
      last.extras.files.push(url)
      return copy
    })
  }

  return { items, add, remove, clear, total, attachFile }
}
