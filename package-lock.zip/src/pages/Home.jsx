import React from 'react'
import { Link } from 'react-router-dom'
export default function Home(){
  return (
    <div>
      <section className="hero">
        <div className="left">
          <h1>Make it yours — Grizzlies</h1>
          <p>Fast WhatsApp checkout • Custom sublimation • Premium merch</p>
          <div style={{display:'flex',gap:12,marginTop:18}}>
            <Link to="/products" className="button">Shop Merch</Link>
            <Link to="/sublimation" className="button ghost">Sublimation</Link>
          </div>
        </div>
        <div className="right">
          <div className="order-card">
            <div className="title">Merch</div>
            <div className="desc">Ready-made items — tees, hoodies & more. Quick checkout via WhatsApp.</div>
            <div style={{marginTop:12}}><Link to="/products" className="button">Browse</Link></div>
          </div>
          <div className="order-card">
            <div className="title">Sublimation</div>
            <div className="desc">Custom team kits, netball dresses and bulk sublimation orders.</div>
            <div style={{marginTop:12}}><Link to="/sublimation" className="button">Start Order</Link></div>
          </div>
        </div>
      </section>
    </div>
  )
}
